package br.com.senaibrasilia.projetofinal.dao;

import javax.persistence.EntityManager;

import br.com.senaibrasilia.projetofinal.model.Categoria;

public class CategoriaDAO {
	EntityManager entityManager;

	public CategoriaDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public void cadastrar(Categoria categoria) {
		//persist
		this.entityManager.persist(categoria);
	}
	public void alterar(Categoria categoria) {
		//marge
		this.entityManager.merge(categoria);
	}
	public void remover(Categoria categoria) {
		categoria = entityManager.merge(categoria);
		this.entityManager.remove(categoria);
	}

	

}
