package br.com.senaibrasilia.projetofinal.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;

import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;

public class ProdutoDAO {
	
	EntityManager entityManager;

	public ProdutoDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public void cadastrar(Produto produto) {
		//persist
		this.entityManager.persist(produto);
	}
	public void alterar(Produto produto) {
		//marge
		this.entityManager.merge(produto);
	}
	public void remover(Produto produto) {
		produto = entityManager.merge(produto);
		this.entityManager.remove(produto);
	}
	public Produto pesquisarPorCodigo(Long id) {
		//find
		return entityManager.find(Produto.class,id);
	}
	public List<Produto> pesquisaPorNome(String nome) {
		//?
		String jpql = "SELECT p FROM Produto p WHERE p.nome = :nome";
		return entityManager.createQuery(jpql, Produto.class).setParameter("nome",nome).getResultList();
		
	}
	public List<Produto> pesquisarTodos(){
		//query -JPQL
		//ArrayList - List
		//Lambda - Java8
		String jpql = "SELECT p FROM Produto p";
		return entityManager.createQuery(jpql, Produto.class).getResultList();
		
	}
	public List<Produto> pesquisaPorNomeDaCategoria(String nome){
		String jpql = "SELECT p FROM Produto p WHERE p.descricao.nome = :nome";
		return entityManager.createQuery(jpql, Produto.class).setParameter("nome",nome).getResultList();
	}

	public BigDecimal pesquisaPrecoDoProdutoComNome(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
