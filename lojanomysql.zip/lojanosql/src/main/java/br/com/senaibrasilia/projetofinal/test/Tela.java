package br.com.senaibrasilia.projetofinal.test;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import br.com.senaibrasilia.projeto.util.JPAUtil;
import br.com.senaibrasilia.projetofinal.dao.CategoriaDAO;
import br.com.senaibrasilia.projetofinal.dao.ProdutoDAO;
import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;

//import teste.ContatoController;
//import teste.ContatoFrame;

public class Tela extends JFrame {
	private JLabel lbNome, IbDescricao, IbPreco;
    private JTextField txtNome, txtDescricao, txtPreco, txtLocalizar;
    private JButton btnCadastrar, btnAlterar, btnExcluir, btnLocalizar;

    //private List contatoList = new ContatoController().listaContatos();
//    private int registroAtual = 0;
//	private Long key;

    public Tela() {
        super("Contatos");
        
        
        //cadastrarProduto();
        
        EntityManager conect = JPAUtil.getEntityManager();
        ProdutoDAO produtoDAO = new ProdutoDAO(conect);
        CategoriaDAO categoriaDAO = new CategoriaDAO(conect);
        
        Container tela = getContentPane();
        setLayout(null);
        lbNome = new JLabel("Produto");
        IbDescricao = new JLabel("Descri��o");
        IbPreco = new JLabel("Pre�o");

        lbNome.setBounds(10, 10, 240, 15);
        IbDescricao.setBounds(10, 50, 240, 15);
        IbPreco.setBounds(10, 90, 240, 15);

        lbNome.setForeground(Color.BLACK);
        IbDescricao.setForeground(Color.BLACK);
        IbPreco.setForeground(Color.BLACK);

        lbNome.setFont(new Font("Courier New", Font.BOLD, 14));
        IbDescricao.setFont(new Font("Courier New", Font.BOLD, 14));
        IbPreco.setFont(new Font("Courier New", Font.BOLD, 14));

        tela.add(lbNome);
        tela.add(IbDescricao);
        tela.add(IbPreco);

        txtNome = new JTextField();
        txtDescricao = new JTextField();
        txtPreco = new JTextField();

        txtNome.setBounds(10, 25, 265, 20);
        txtDescricao.setBounds(10, 65, 265, 20);
        txtPreco.setBounds(10, 105, 265, 20);

        tela.add(txtNome);
        tela.add(txtDescricao);
        tela.add(txtPreco);

        btnCadastrar = new JButton("Cadastrar");
        btnAlterar = new JButton("Alterar");
        btnExcluir = new JButton("Excluir");
//        btnClear = new JButton("Limpar");
//        btnPrimeiro = new JButton("|<");
//        btnAnterior = new JButton("<<");
//        btnProximo = new JButton(">>");
//        btnUltimo = new JButton(">|");

        btnCadastrar.setBounds(280, 25, 95, 20);
        btnAlterar.setBounds(280, 65, 95, 20);
        btnExcluir.setBounds(280, 105, 95, 20);

        tela.add(btnCadastrar);
        tela.add(btnAlterar);
        tela.add(btnExcluir);

//        btnPrimeiro.setBounds(10, 135, 50, 20);
//        btnAnterior.setBounds(60, 135, 50, 20);
//        btnClear.setBounds(110, 135, 75, 20);
//        btnProximo.setBounds(185, 135, 50, 20);
//        btnUltimo.setBounds(235, 135, 50, 20);
//
//        tela.add(btnPrimeiro);
//        tela.add(btnAnterior);
//        tela.add(btnClear);
//        tela.add(btnProximo);
//        tela.add(btnUltimo);

        JLabel lbLocalizar = new JLabel("Pesquisa");
        lbLocalizar.setBounds(10, 130, 220, 20);
        lbLocalizar.setFont(new Font("Courier New", Font.BOLD, 14));

        txtLocalizar = new JTextField();
        txtLocalizar.setBounds(10, 150, 265, 20);

        btnLocalizar = new JButton("Ir");
        btnLocalizar.setBounds(280, 150, 95, 20);
        
        final JRadioButton vestuario;
		final JRadioButton tecnologia;
        
        vestuario = new JRadioButton("Vestu�rio");
        vestuario.setBounds(100, 130, 80, 20);
        vestuario.setMnemonic(KeyEvent.VK_B);
        vestuario.setActionCommand("Vestuario");
        vestuario.setSelected(true);
        
        
        tecnologia = new JRadioButton("Tecnologia");
        tecnologia.setBounds(180, 130, 100, 20);
        tecnologia.setMnemonic(KeyEvent.VK_C);
        tecnologia.setActionCommand("Tecnologia");
        
        ButtonGroup selecao = new ButtonGroup();
        selecao.add(tecnologia);
        selecao.add(vestuario);

        tela.add(tecnologia);
        tela.add(vestuario);
        tela.add(lbLocalizar);
        tela.add(txtLocalizar);
        tela.add(btnLocalizar);

        setSize(400, 300);
        setVisible(true);
        setLocationRelativeTo(null);
        
        
        btnCadastrar.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	
                    	if(vestuario.isSelected()) {
                    		try {	
                    			Categoria vestuarios=new Categoria("VESTUARIO");
								categoriaDAO.cadastrar(vestuarios);
	                    		produtoDAO.cadastrar(new Produto(txtNome.getText(),txtDescricao.getText(),new BigDecimal(txtPreco.getText()),vestuarios));
	                    		txtNome.setText("");
	                    		txtDescricao.setText("");
	                    		txtPreco.setText("");
	                    		
	                    		conect.getTransaction().commit();
	                    		JOptionPane.showMessageDialog(null,"Cadastro Realizado com Sucesso.");
                    		}catch ( Exception a) {
                    			JOptionPane.showMessageDialog(null,"Valor inserido invalido");
                    		}
                    		
                    	}else if(tecnologia.isSelected()) {
                    		try {
	                    		produtoDAO.cadastrar(new Produto(txtNome.getText(),txtDescricao.getText(),new BigDecimal(txtPreco.getText()),new Categoria("TECNOLOGIA")));
	                    		txtNome.setText("");
	                    		txtDescricao.setText("");
	                    		txtPreco.setText("");
	                    		JOptionPane.showMessageDialog(null,"Cadastro Realizado com Sucesso.");
	                    		conect.getTransaction().commit();
	                    		conect.close();
                    		}catch ( Exception a) {
                    			JOptionPane.showMessageDialog(null,"Valor inserido invalido");
                    		}
                    	}
                    	

                    	
                    }
                }
        );
        

        btnAlterar.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JOptionPane.showMessageDialog(null, "Recurso n�o implementado.\nEspere atualiza��es futuras");
                    }
                }
        );

        btnExcluir.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	JOptionPane.showMessageDialog(null, "Recurso n�o implementado.\nEspere atualiza��es futuras");
                    }
                }
        );

        btnLocalizar.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	if(tecnologia.isSelected() && txtLocalizar.getText().equals(null)) {
                    		List<Produto> tecnologias = produtoDAO.pesquisaPorNomeDaCategoria("TECNOLOGIA");
                    		tecnologias.forEach(p2 -> JOptionPane.showMessageDialog(null,"\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
                    		
                    	}else if(vestuario.isSelected() && txtLocalizar.getText().equals(null)) {
                    		List<Produto> vestuarios = produtoDAO.pesquisaPorNomeDaCategoria("VESTUARIO");
                    		vestuarios.forEach(p2 -> JOptionPane.showMessageDialog(null,"\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
                    	}else if(!txtLocalizar.getText().equals(null)) {
                    		try {
                    			List<Produto> tecnologias = produtoDAO.pesquisaPorNome(txtLocalizar.getText());
                    			tecnologias.forEach(p2 -> JOptionPane.showMessageDialog(null,"\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
                    		}catch (Exception a) {
                    			JOptionPane.showMessageDialog(null, "Produto n�o encontrado\n");
                    			List<Produto> tecnologias = produtoDAO.pesquisaPorNomeDaCategoria("TECNOLOGIA");
                        		tecnologias.forEach(p2 -> JOptionPane.showMessageDialog(null,"\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
                        		List<Produto> vestuarios = produtoDAO.pesquisaPorNomeDaCategoria("VESTUARIO");
                        		vestuarios.forEach(p2 -> JOptionPane.showMessageDialog(null,"\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
                        		
                    		}
                    		
                    	}
                		
                		
                		
                    }
                }
        );

	
    }
    private static void cadastrarProduto() {
//		Categoria vestuarios = new Categoria("VESTUARIO");
//		Produto roupa1 = new Produto("Cal�a Feminina", "Sarja Wide",new BigDecimal("109"),vestuarios);
//		Produto roupa2 = new Produto("Blusa Regata Feminina", "Textura Ombro",new BigDecimal("29"),vestuarios);
//		Produto roupa3 = new Produto("Calca Jeans", "Super Slim",new BigDecimal("529"),vestuarios);
//		Produto roupa4 = new Produto("Bermuda Chino", "El�stico Solid ",new BigDecimal("329"),vestuarios);
//		
//		
//		Categoria tecnologia = new Categoria("TECNOLOGIA");
//		Produto celular1 = new Produto("Xiaomi Redmi", "Xiome",new BigDecimal("800"),tecnologia);
//		Produto celular2 = new Produto("iPhone 13", "Apple",new BigDecimal("5000"),tecnologia);
//		Produto celular3 = new Produto("Galaxy S22 Ultra 5G", "Samsung",new BigDecimal("7300"),tecnologia);
//		Produto celular4 = new Produto("Moto G8 Power", "Motorola",new BigDecimal("5000"),tecnologia);
//
//
//		
//		
//		EntityManager conect = JPAUtil.getEntityManager();		
//		ProdutoDAO produtoDAO = new ProdutoDAO(conect);		
//		CategoriaDAO categoriaDAO = new CategoriaDAO(conect);
//		
//		conect.getTransaction().begin();		
//		categoriaDAO.cadastrar(tecnologia);
//		produtoDAO.cadastrar(celular1);
//		produtoDAO.cadastrar(celular2);
//		produtoDAO.cadastrar(celular3);
//		produtoDAO.cadastrar(celular4);
//		
//		categoriaDAO.cadastrar(vestuarios);
//		produtoDAO.cadastrar(roupa1);
//		produtoDAO.cadastrar(roupa2);
//		produtoDAO.cadastrar(roupa3);
//		produtoDAO.cadastrar(roupa4);
//		
//		
//		conect.getTransaction().commit();
//		conect.close();
		
	}
	
	public static void main(String[] args) {
        Tela frame = new Tela();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
