package br.com.senaibrasilia.projeto.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Conexao {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Cliente-PU");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
}
